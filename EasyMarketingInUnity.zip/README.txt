INSTRUCTIONS
--------------------------------------------
1.) Find the Repository at https://github.com/JoshuaKey/EasyMarketingInUnity

2.) Download the Zip file (EasyMarketingInUnity.zip)

3.) Unzip the file

4.) Copy and Paste the EasyMarketingInUnity folder at the root of the Assets folder

5.) Open Window->EasyMarketingInUnity->Help

6.) Enjoy!
--------------------------------------------

ERRORS
--------------------------------------------
Error: "Opening File ... The process can not access the file because it is being used by another process."
	Hit Cancel. Unity is being a baby because it can't access the file.
--------------------------------------------

FOLDERS
--------------------------------------------
Easy Marketing In Unity comes with 4 folders

Editor is responsible for all the code. You can look at it for inspiration, but it probably won't help.

Save contains Server Data, Preferences, and Log Information

Plugins contains all the external data. This includes the DLL and Server. I'd advise not touching this folder.

Textures contains all the textures used in the Plugin.
--------------------------------------------

NOTES
--------------------------------------------
Easy Marketing in Unity has plans to support many sites and many OSs

Currently it only supports TWITTER and WINDOWS.

If you are interested in a particular site, Contact me and tell me to hurry up.
Email: JoshJKey98@yahoo.com
--------------------------------------------

WHAT CURRENTLY DOESNT WORK
--------------------------------------------
Any site other than Twitter
Any OS other than Windows

Responses are Finicky

Synchronous in Settings
Restart on Crash in Settings
Notifications
Notifications Settings 

Replying
Liking
--------------------------------------------
